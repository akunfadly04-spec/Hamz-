const fs = require('fs')

global.owner = "6283848446158" //owner number
global.dbny = "6283848446158" //Isi nomor bot lu
global.footer = "Yakuza Crasher" //footer section
global.status = true //"self/public" section of the bot
global.lol = "https://whatsapp.com/channel/0029Vb8uZ1V0lwgofojloh0n";
global.mess = {
    owner: "lu bukan owner😏"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
